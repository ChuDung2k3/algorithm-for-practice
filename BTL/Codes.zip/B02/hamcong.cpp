//ham co doi mac dinh
#include<bits/stdc++.h>
using namespace std;

int cong(int a=2,int b=7) {return a+b;} //thuc thi cua ham
float cong(float a=2,float b=7) {return a*b;} //thuc thi cua ham



int main()
{
	cout<<"Tong 4+5 = "<<cong(4,5); //goi ham dong 5
	cout<<"\nTong 4.2*4.8 = "<<cong(4.2f,4.8f);//ham dong 6
}


